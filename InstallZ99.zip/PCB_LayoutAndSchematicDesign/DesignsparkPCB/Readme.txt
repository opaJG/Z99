Dimensions of X2Y4Z PCB are 165 X 85 mm.

X2Y4Z.zip

contains the data to send to PCB manufacturer for manufacturing of the double sided PCB.