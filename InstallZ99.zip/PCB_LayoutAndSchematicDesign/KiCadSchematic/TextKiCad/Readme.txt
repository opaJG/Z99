TextKiCad-F_SilkSS.gbr

and

TextKiCad-F_Cu.gbr

contain an example of a text made with KiCad