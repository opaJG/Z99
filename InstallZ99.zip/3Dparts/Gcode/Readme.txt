The *.gcode files are not included.
The size of them is 240 MB.
It is better to build the gcode files 
with Slic3r from the *.stl files in directory
C\Z99\3DParts\STL